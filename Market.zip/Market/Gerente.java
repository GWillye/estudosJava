package Tarefas;

public final class Gerente extends Funcionario {
	
	//Attributes
	private Funcionario[] funcionario;
	private double bonusAnual;
	
	//Constructor
	public Gerente(String cPF, String nome, String idade, int numCadastro, double salario, Funcionario[] funcionario,
			double bonusAnual) {
		super(cPF, nome, idade, numCadastro, salario);
		this.funcionario = funcionario;
		this.bonusAnual = bonusAnual;
	}

	//Getters and Setters
	public Funcionario[] getFuncionario() {
		return funcionario;
	}

	public void setFuncionario(Funcionario[] funcionario) {
		this.funcionario = funcionario;
	}

	public double getBonusAnual() {
		return bonusAnual;
	}

	public void setBonusAnual(double bonusAnual) {
		this.bonusAnual = bonusAnual;
	}
	
	public String ToString() {
		return "Gerente de nome " + getNome();
	}
}
