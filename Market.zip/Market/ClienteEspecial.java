package Tarefas;

public final class ClienteEspecial extends Cliente {

	//Attributes
	private double descontoFixo;
	
	//Constructor
	public ClienteEspecial(String cPF, String nome, String idade, String endereco, String telefone) {
		super(cPF, nome, idade, endereco, telefone);
		// TODO Auto-generated constructor stub
	}
	
	//Getters and Setters
	public double getDescontoFixo() {
		return descontoFixo;
	}

	public void setDescontoFixo(double descontoFixo) {
		this.descontoFixo = descontoFixo;
	}
	
	public String ToString() {
		return "Cliente especial de nome " + getNome() + "e desconto fixo de " + getDescontoFixo();
	}
}
