package Tarefas;

public abstract class Pessoa {
	
	//Attributes
	protected String CPF;
	protected String nome;
	protected String idade;
	
	//Constructor
	public Pessoa(String cPF, String nome, String idade) {
		CPF = cPF;
		this.nome = nome;
		this.idade = idade;
	}
	
	//Getters and Setters
	public String getCPF() {
		return CPF;
	}

	public void setCPF(String cPF) {
		CPF = cPF;
	}

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public String getIdade() {
		return idade;
	}

	public void setIdade(String idade) {
		this.idade = idade;
	}
	
	public String ToString()
	{
		return "Pessoa de nome " + getNome() + "e " + getIdade() + " anos"; 
	}
}
