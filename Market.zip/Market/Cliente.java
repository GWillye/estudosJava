package Tarefas;

public class Cliente extends Pessoa {
	
	//Attributes
	protected String endereco;
	protected String telefone;
	
	//Constructor
	public Cliente(String cPF, String nome, String idade, String endereco, String telefone) {
		super(cPF, nome, idade);
		this.endereco = endereco;
		this.telefone = telefone;
	}
	
	//Getters and Setters
	public String getEndereco() {
		return endereco;
	}

	public void setEndereco(String endereco) {
		this.endereco = endereco;
	}

	public String getTelefone() {
		return telefone;
	}

	public void setTelefone(String telefone) {
		this.telefone = telefone;
	}
	
	public String ToString() {
		return "Cliente de nome " + getNome() + "e telefone " + getTelefone();
	}
}
