package Tarefas;

public class Funcionario extends Pessoa {
	
	//Attributes
	private int numCadastro;
	private double salario;
	
	//Constructor
	public Funcionario(String cPF, String nome, String idade, int numCadastro, double salario) {
		super(cPF, nome, idade);
		this.numCadastro = numCadastro;
		this.salario = salario;
	}

	//Getters and Setters
	public int getNumCadastro() {
		return numCadastro;
	}

	public void setNumCadastro(int numCadastro) {
		this.numCadastro = numCadastro;
	}

	public double getSalario() {
		return salario;
	}

	public void setSalario(double salario) {
		this.salario = salario;
	}
	
	public String ToString(){
		return "Funcionario de nome " + getNome() + "e numero de cadastro " + getNumCadastro();
	}
	
}
