package Tarefas;

public class main {
	private Author author;
	private Book book;
	
	public static void main(String[] args)
	{
		Author author = new Author("Rick Riordan", "idk@idk.com", 'M');
		Book book = new Book("Percy Jackson", author, 35.0, 2000);
		
		System.out.println("Book's name: " + book.getName());
		System.out.println("Book's price: " + book.getPrice());
		System.out.println("Quantity in Stock: " + book.getQtyInStock());
		System.out.println("Author's email: " + book.author.getEmail());
		System.out.println("Author's name: " + book.author.getName());
		System.out.println("Author's gender: " + book.author.getGender());
		
	}
}
