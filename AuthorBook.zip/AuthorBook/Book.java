package Tarefas;

public class Book {
	
	//Attributes
	protected String name;
	protected Author author;
	protected double price;
	protected int qtyInStock;

	
	//Constructor
	public Book(String name, Author author, double price, int qtyInStock) {
		this.name = name;
		this.author = author;
		this.price = price;
		this.qtyInStock = qtyInStock;
	}

	//Getters and Setters
	public double getPrice() {
		return price;
	}


	public void setPrice(double price) {
		this.price = price;
	}


	public int getQtyInStock() {
		return qtyInStock;
	}


	public void setQtyInStock(int qtyInStock) {
		this.qtyInStock = qtyInStock;
	}


	public String getName() {
		return name;
	}


	public Author getAuthor() {
		return author;
	}
	
	public String ToString()
	{
		return "Book called " + getName() + "and author " + author.getName();
	}
	
}
