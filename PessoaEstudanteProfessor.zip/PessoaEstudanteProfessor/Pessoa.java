package PessoaEstudanteProfessor;

abstract class Pessoa 
{
	//Attributes
	protected String nome;
	protected String CPF;
	protected int idade;
	protected String[] disciplinas;

	//Constructor
	public Pessoa(String nome, String CPF, int idade, String[] disciplinas)
	{
		this.nome = nome;
		this.CPF = CPF;
		this.idade = idade;
		this.disciplinas = new String[7];
	
		for (int cont = 0; cont < disciplinas.length; cont++) 
		{
			this.disciplinas[cont] = disciplinas[cont];
    	}
	}
	
	//Methods
	public void incrementaidade()
	{
		this.idade ++;
	}
	
	public String getInfo()
	{
		return "Pessoa de nome " + getNome();
	}
	
	//Getters
	public String getNome()
	{
		return this.nome;
	}
	
	public String getCPF()
	{
		return this.CPF;
	}
	
	public int getIdade()
	{
		return this.idade;
	}
	
	public String[] getDisciplinas()
	{
		return this.disciplinas;
	}

}