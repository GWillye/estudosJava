package PessoaEstudanteProfessor;

public class Professor extends Pessoa {
	
	//Attributes
	private String cadastro;
	
	//Constructor
	public Professor(String nome, String CPF, int idade, String[] disciplinas, String cadastro)
	{
		super(nome, CPF, idade, disciplinas);
		this.cadastro = cadastro;
	}
	
	//Methods
	public String getCadastro()
	{
		return this.cadastro;
	}
	
	public String getInfo()
	{
		return "Professor de cadastro " + getCadastro();
	}
}
