package PessoaEstudanteProfessor;

public class Estudante extends Pessoa
{
	//Attributes
	private String RGA;
	
	//Constructor
	public Estudante(String nome, String CPF, int idade, String[] disciplinas, String RGA)
	{
		super(nome, CPF, idade, disciplinas);
		this.RGA = RGA;
	}
	
	//Methods
	public String getRGA()
	{
		return this.RGA;
	}
	
	public String getInfo()
	{
		return "Aluno de RGA " + getRGA();
	}
}