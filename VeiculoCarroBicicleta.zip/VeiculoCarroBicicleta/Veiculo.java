package VeiculoCarroBicicleta;

abstract class Veiculo 
{
	//Attributes
	protected int nRodas;
	protected String modelo;
	protected int nPass;
	protected int maxPass;
	
	//Constructor
	public Veiculo(int nRodas, String modelo, int maxPass)
	{
		this.nRodas = nRodas;
		this.modelo = modelo;
		this.maxPass = maxPass;
	}
	
	//Methods
	public boolean incPass()
	{
		if (this.nPass < this.maxPass)
		{
			this.nPass ++;
			return true;
		}
		else
		{
			return false;
		}
	}
	
	//Getters
	public String getModelo()
	{
		return this.modelo;
	}
	
	public int getNPass()
	{
		return this.nPass;
	}
	
}
