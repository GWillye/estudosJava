package VeiculoCarroBicicleta;

public class Carro extends Veiculo 
{
	//Attributes
	private String combustivel;
	private int potencia;
	
	//Constructor
	public Carro(String modelo, String combustivel, int potencia)
	{
		super(4, modelo, 5);
		this.combustivel = combustivel;
		this.potencia = potencia;
	}
	
	//Getters
	public String getCombustivel()
	{
		return this.combustivel;
	}
	
	public int getPotencia()
	{
		return this.potencia;
	}
	
}
