package VeiculoCarroBicicleta;

public class Bicicleta extends Veiculo
{
	//Attributes
	private int aro;
	private int nMarchas;
	
	//Constructor
	public Bicicleta(String modelo, int aro, int nMarchas)
	{
		super(2, modelo, 1);
		this.aro = aro;
		this.nMarchas = nMarchas;
	}
	
	//Getters
	public int getAro()
	{
		return this.aro;
	}
	
	public int getMarchas()
	{
		return this.nMarchas;
	}
}
