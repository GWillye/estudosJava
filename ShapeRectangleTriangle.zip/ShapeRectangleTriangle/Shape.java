package Tarefas;

public class Shape {
	//Attributes
	protected String color;
	
	//Constructor
	public Shape(String color) {
		super();
		this.color = color;
	}

	public String getColor() {
		return color;
	}

	public void setColor(String color) {
		this.color = color;
	}
	
	public String ToString() {
		return "Shape with color " + getColor();
	}
}
