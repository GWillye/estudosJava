package Tarefas;

public final class Rectangle extends Shape {
	
	//Attributes
	private double length;
	private  double width;
	
	//Constructor
	public Rectangle(String color, double length, double width) {
		super(color);
		this.length = length;
		this.width = width;
	}

	public double getLength() {
		return length;
	}

	public void setLength(double length) {
		this.length = length;
	}

	public double getWidth() {
		return width;
	}

	public void setWidth(double width) {
		this.width = width;
	}
	
	public String ToString() {
		return "Rectangle with length " + getLength() + "and width " + getWidth();
	}
}
