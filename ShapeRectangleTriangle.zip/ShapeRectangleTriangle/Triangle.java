package Tarefas;

public final class Triangle extends Shape {
	
	//Attributes
	private double base;
	private double height;
	
	//Constructor
	public Triangle(String color, double base, double height) {
		super(color);
		this.base = base;
		this.height = height;
	}

	//Getters and Setters
	public double getBase() {
		return base;
	}

	public void setBase(double base) {
		this.base = base;
	}

	public double getHeight() {
		return height;
	}

	public void setHeight(double height) {
		this.height = height;
	}
	
	public String ToString() {
		return "Triangle with base " + getBase() + "and height " + getHeight();
	}
	
}
