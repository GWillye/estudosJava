package UmGrupoDeRPG;

import java.util.List;

public class Personagem implements Comparable<Personagem>
{
	//Attributes
	private String nome;
	private int nivel;
	private int hp;
	private List<String> feiticos;
	
	//Constructor
	public Personagem(String nome, int nivel, int hp, List<String> feiticos)
	{
		this.nome = nome;
		this.nivel = nivel;
		this.hp = hp;
		this.feiticos = feiticos;
	}
	
	//Methods
	public int compareTo(Personagem outroP)
	{
		return score() - outroP.score();
	}
	
	public int score()
	{
		return this.nivel * this.hp + this.feiticos.size();
	}
	
	public String getNome()
	{
		return this.nome;
	}
	
}
