package UmGrupoDeRPG;

import java.util.List;
import java.util.Collections;

public class Grupo 
{
	//Attributes
	private List<Personagem> personagens;
	
	//Constructor
	public Grupo(List<Personagem> personagens)
	{
		this.personagens = personagens;
	}
	
	//Methods
	public void ordenaPersonagens()
	{
		Collections.sort(personagens);
	}
	
	public void imprimePersonagens()
	{
		for(Personagem personagem : personagens)
		{
			System.out.println(personagem.getNome());
		}
	}
	
}
