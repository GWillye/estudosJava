package homeworks;

import java.util.ArrayList;
import java.util.List;

public class main {
	
	public static void main(String[] args){
		
		List<Livro> listaLivros = new ArrayList<>();
		
        LivroDeDrama livroDrama = new LivroDeDrama("Livro de Drama 1", "Autor Drama", 5);
        livroDrama.valorLivro = 10.0;
        listaLivros.add(livroDrama);

        LivroDeFiccao livroFiccao = new LivroDeFiccao("Livro de Ficção 1", "Autor Ficção", 2000);
        livroFiccao.valorLivro = 15.0;
        listaLivros.add(livroFiccao);
        
        for (Livro livro : listaLivros)
        {
        	livro.computaPreco();
        }
		
		
	}
}