package homeworks;

public class LivroDeDrama extends Livro {
	
	//Attributes
	protected int qtdPersonagens;

	//Constructor
	public LivroDeDrama(String titulo, String autor, int qtdPersonagens) {
		super(titulo, autor);
		this.qtdPersonagens = qtdPersonagens;
	}

	//Getters and Setters
	public int getQtdPersonagens() {
		return qtdPersonagens;
	}

	public void setQtdPersonagens(int qtdPersonagens) {
		this.qtdPersonagens = qtdPersonagens;
	}
	
	//Methods
	public void computaPreco() {
		System.out.println("O preco do livro eh: " + (getQtdPersonagens() / 2 * valorLivro));	}
}
