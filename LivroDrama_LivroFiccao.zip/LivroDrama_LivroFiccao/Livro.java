package homeworks;

public abstract class Livro {
	
	//Attributes
	protected String titulo;
	protected String autor;
	protected double valorLivro;
	
	//Constructor
	public Livro(String titulo, String autor) {
		super();
		this.titulo = titulo;
		this.autor = autor;
	}
	
	//Getters and Setters
	public String getTitulo() {
		return titulo;
	}

	public void setTitulo(String titulo) {
		this.titulo = titulo;
	}

	public String getAutor() {
		return autor;
	}

	public void setAutor(String autor) {
		this.autor = autor;
	}

	public double getValorLivro() {
		return valorLivro;
	}

	public void setValorLivro(double valorLivro) {
		this.valorLivro = valorLivro;
	}
	
	//Methods
	public abstract void computaPreco();
}
