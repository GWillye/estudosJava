package homeworks;

public class LivroDeFiccao extends Livro {
	
	//Attributes
	protected int ano;

	//Constructor
	public LivroDeFiccao(String titulo, String autor, int ano) {
		super(titulo, autor);
		this.ano = ano;
	}

	//Getters and Setters
	public int getAno() {
		return ano;
	}

	public void setAno(int ano) {
		this.ano = ano;
	}
	
	//Methods
	public void computaPreco()
	{
		System.out.println("O preco eh " + (getAno() / 1000 * valorLivro));
	}
}
